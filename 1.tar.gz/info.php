<?php
include_once ('function.php');

$article = getNewsById($_GET['id']);
dd($article);




