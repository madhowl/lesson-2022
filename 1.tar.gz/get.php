<?php
include_once ('function.php');
$news = getAllNews();
foreach ($news as $n){

    echo '<a href="info.php&id='.$n['id'].'">'.$n['title'].'</a><br>';
}
?>
<a href=""></a>
<hr>
<h1>form $_post</h1>
<form action="" method="post">
    <input type="text" name="email">
    <input type="submit" value="send">
</form>
<img src="" alt="">